package client;

import java.io.Serializable;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class Client implements Serializable {

    
	private static final long serialVersionUID = 1L;

	
	public static String[][] COMMANDS = new String[][] {
            {"Register Customer", "CUSTOMER", "Name"},
            {"Register Vehicle",  "CAR",      "License", "Customer"},
            {"Start Parking",     "PARK",     "Permit Id", "Time"},
            {"Finish Parking",    "PARK",     "Permit Id", "Time"},
            {"Get Charges",       "CHARGES",  "Customer", "Car"},
    };
    

    	  public String getJsonObject() {
    	    Gson gson = new GsonBuilder().create();
    	    return gson.toJson(COMMANDS);
    	  }
    	  
    	  public static ParkingGui fromJsonString(String jsonString) {
    	    Gson gson = new GsonBuilder().setPrettyPrinting().create();
    	    return gson.fromJson(jsonString, ParkingGui.class);
    	  }
    	  
    	  public String[][] getCommandRequest() {
    	    return COMMANDS;
    	  }

    private static final int PORT = 7777;
    private static final String SERVER = "localhost";

    public static List<String> runCommand(String command, Map<String, String> data)
            throws IOException {

        InetAddress host = InetAddress.getByName(SERVER);
        ArrayList<String> response = new ArrayList<>();
        try (Socket link = new Socket(host, PORT);
             Scanner scanner = new Scanner(link.getInputStream());) {

            // connect to server
            System.out.println("You are now connected to: " + host.getHostAddress());
            PrintWriter output = new PrintWriter(link.getOutputStream());

            for (String value : data.values()) {
                command += String.format("%n%s", value);
            }
            output.println(command);
            output.println("end");
            output.flush();

            while (true) {
                String line = scanner.nextLine();
                if (line.equals("end")) {
                    break;
                }
                response.add(line);
            }
        }
        return response;

    }

    public static Map<String, Command> commands() {
        Map<String, Command> commands = new HashMap<>();
        for (String[] description : COMMANDS) {
            commands.put(description[1], new Command(description[0], description[1],
                    Arrays.asList(description).subList(2, description.length)));
        }
        return commands;
    }

    /**
     * Run this as: $ java ict4300.week8.client.Client COMMAND label1=value1 label2=value2 ...
     * Use LIST to get the list of commands and their labels.
     */
    public static void main(String[] args) throws IOException {

        if (args.length == 0 || args[0].equals("LIST")) {
            System.out.println("Here are the commands we know about.");
            System.out.println(
                    "Usage: $ java client.Client COMMAND label1=value1 label2=value2 ...");
            System.out.println();
            for (String[] description : COMMANDS) {
                System.out.format("%s: %s ", description[0], description[1]);
                for (int i = 2; i < description.length; ++i) {
                    System.out.format("%s=value ", description[i].replaceAll(" ", "").toLowerCase());
                }
                System.out.println();
            }
            return;
        }

        Command command = commands().get(args[0]);
        if (command == null) {
            System.out.println("Unrecognised command: " + args[0]);
            System.out.print("Known commands: ");
            String comma = "";
            for (String[] description : COMMANDS) {
                System.out.print(comma + description[1]);
                comma = ", ";
            }
            System.out.println();
            return;
        }
        Map<String, String> values = new LinkedHashMap<String, String>();
        for (String label : command.fieldNames()) {
            for (int i = 0; i < args.length; ++i) {
                if (args[i].startsWith(label.replaceAll(" ", "").toLowerCase())) {
                    values.put(label, args[i].replaceAll(".*=", ""));
                    break;
                }
            }
        }
        for (String output : Client.runCommand(args[0], values)) {
            System.out.println(output);
        }
    }
}
