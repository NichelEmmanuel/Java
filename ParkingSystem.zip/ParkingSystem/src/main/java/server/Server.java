package server;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

import parkingsystem.Address;
import parkingsystem.ParkingOffice;

public class Server extends Thread{
	private Socket client;

	public HandleRemoteClient(Socket s, ParkingService service) {
	  client = s;
	  this.service = service;
	}



    static {
        System.setProperty(
                "java.util.logging.SimpleFormatter.format", "%1$tc %4$-7s (%2$s) %5$s %6$s%n");
    }

    private static final Logger logger = Logger.getLogger(Server.class.getName());

    private final int PORT = 7777;

    private final ParkingService service;

    public Server(ParkingService service) {
        this.service = service;
    }

    public void startServer() throws IOException {
        logger.info("Starting server: " + InetAddress.getLocalHost().getHostAddress());
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            serverSocket.setReuseAddress(true);
            while (true) {
                Socket client = serverSocket.accept();
                Thread.start();
            }
            
        }
    }
    
    
    
    @Override
    public void run() {
      try (ObjectOutputStream osw =
        new ObjectOutputStream(client.getOutputStream())) {
        String output;
        output = service.handleInputObject(client.getInputStream());
        osw.writeObject(output);
      }

    private void handleClient(Socket client) {
        try (PrintWriter pw = new PrintWriter(client.getOutputStream())) {
            String output;
            try {
                output = service.handleInput(client.getInputStream());
            } catch (RuntimeException ex) {
                ex.printStackTrace();
                output = ex.getMessage();
            }

            pw.println(output);
            pw.println("end");
            pw.flush();

        } catch (IOException e) {
            logger.log(Level.WARNING, "Failed to read from client.", e);
        } finally {
            try {
                client.close();
            } catch (IOException e) {
                logger.log(Level.WARNING, "Failed to close client socket.", e);
            }
        }
    }

    /**
     * Run this as:
     * $ java ict4300.week8.server.Server
     */
    public static void main(String[] args) throws Exception {
        ParkingOffice parkingOffice = new ParkingOffice("Office",  new Address());
        ParkingService service = new ParkingService(parkingOffice);

        new Server(service).startServer();
    }
}
