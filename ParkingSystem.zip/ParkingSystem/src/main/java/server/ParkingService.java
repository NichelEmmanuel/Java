package server;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import parkingsystem.Car;
import parkingsystem.Customer;
import parkingsystem.ParkingOffice;

public class ParkingService {
    protected final ParkingOffice parkingOffice;

    public ParkingService(ParkingOffice parkingOffice) {
        this.parkingOffice = parkingOffice;
    }

    protected String handleInput(InputStream in) {
        @SuppressWarnings("resource")
        // The scanner and input stream will be closed when we disconnect
        Scanner scanner = new Scanner(in);
        ArrayList<String> data = new ArrayList<>();
        while (scanner.hasNext()) {
            String token = scanner.nextLine();
            if (token.equals("end")) {
                break;
            }
            data.add(token);
        }
        System.out.println("data: " + data);
        return performCommand(data.remove(0), data);

    }

    private String performCommand(String command, List<String> args) {
        String matched;
        switch (command) {
            case "CUSTOMER":
                return parkingOffice.registerCustomer(new Customer(args.get(0))).toString();
            case "CAR":
                return parkingOffice.registerCar(new Car(args.get(0), new Customer(args.get(1)))).toString();
            case "PARK":
                matched = "park";
                break;
            case "CHARGES":
                matched = "charges";
                break;
            default:
                matched = "unknown";
        }
        matched += ": " + args;
        return matched;
    }

}
