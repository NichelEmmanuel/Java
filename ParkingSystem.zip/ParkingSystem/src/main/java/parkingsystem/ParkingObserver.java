package parkingsystem;
//* This is observer class for parking lot to check details  parking activity.
//* CreatedOn 07/07/2020;
// created by Nichel Emmanuel

public abstract class ParkingObserver {
    public abstract void vehicleEntry(ParkingPermit customerPermit);
    public abstract void vehicleExit(ParkingPermit customerPermit, ParkingLot lot);
}
