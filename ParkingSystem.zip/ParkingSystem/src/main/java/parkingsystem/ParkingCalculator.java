package parkingsystem;
// This class calulates the parking for a car based
// on start and end time for a parking lot.
// CreatedOn 07/07/2020;
// created by Nichel Emmanuel

public abstract class ParkingCalculator {
    ParkingCalculator(){};
    //* This constructor will set  attributes for timeParked and parkingLot,
    // Permit,parkingLot,start,end time.
    public abstract long calculate(ParkingPermit Permit, ParkingLot parkingLot,
                                   java.time.LocalDateTime start, java.time.LocalDateTime end);
}
