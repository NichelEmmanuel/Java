package parkingsystem;

//* This class contains the parking lot details.
//* CreatedOn 07/07/2020;
// created by Nichel Emmanuel

import java.util.ArrayList;

public class ParkingLot implements ParkingActor {
    private String id;
    private String parkingLotName;
    private Address parkingLotAddress ;
    private long price;
    public ArrayList<ParkingObserver> listOfObservers = null;

    //* This constructor will set values for parking id,parkingLotName,parkingLotAddress and price
    public ParkingLot (String id, String parkingLotName, Address parkingLotAddress, long price) {
        this.id = id;
        this.parkingLotName = parkingLotName;
        this.parkingLotAddress = parkingLotAddress;
        this.price = price;
    }
//* This constructor will calculate the parking charge based on car type.

    public Money getDailyRate(Car CustomerCar)
    {
        Money AmountToCharge = new Money(0,"USD");
        if(CustomerCar.getCarType() == Car.CarType.COMPACT)
        {
            AmountToCharge.setAmount((long) (this.price * .8));
        }
        else
        {
            AmountToCharge.setAmount(this.price);
        }
        return AmountToCharge;
    }

    //*  This method  gets and returns value for parking id.
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    //*  This method  gets and returns value for parkingLotName.
    public String getParkingLotName() {
        return parkingLotName;
    }

    public void setParkingLotName(String parkingLotName) {
        this.parkingLotName = parkingLotName;
    }

    //*  This method  gets and returns value for parkingLotAddress.
    public Address getParkingLotAddress() {
        return parkingLotAddress;
    }

    public void setParkingLotAddress(Address parkingLotAddress) {
        this.parkingLotAddress = parkingLotAddress;
    }
    //*  This method  gets and returns value for price.
    public long getPrice() {
        return price;
    }

    public void register(ParkingObserver parkingObserverToRegister){
        listOfObservers.add(parkingObserverToRegister);
    }

    public void vehicleExit(ParkingPermit customerPermit) {
        for(int i = 0; i < listOfObservers.size(); i++) {
            listOfObservers.get(i).vehicleExit(customerPermit, this);
        }
    }
}
