package parkingsystem;
// This class contains Street1, Street2,  City, State, and postal code details of customers.
// CreatedOn 07/07/2020;
// created by Nichel Emmanuel

import java.util.ArrayList;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class ParkingService {
    ArrayList<ParkingTransaction> listOfCharges = null;
    ParkingOffice POInstance;
    static DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    public ParkingService()
    {
        String streetAddress1 = "2199 S University Blvd, ";
        String streetAddress2 = "";
        String city = "Denver, ";
        String state = "CO";
        String zipcode = "80208";
        Address ParkingOfficeAddress = new Address (streetAddress1, streetAddress2, city, state,
                zipcode);
        this.POInstance = new ParkingOffice("University of Denver",ParkingOfficeAddress);

    }

    //constructor sets parameters for command and args
    public String performCommand(String command, List<String> args)
    {
        //Command to register a new customer
        if (command.equalsIgnoreCase("CUSTOMER")) {
            if (args.size() != 9) {
                throw new IllegalArgumentException("A customer requires 9 arguments.");
            }
            registerCustomerCMD(args.get(0), args.get(1), args.get(2), args.get(3),args.get(4),args.get(5),args.get(6),args.get(7),args.get(8));
        }
        //Command to register a new car
        else if (command.equalsIgnoreCase("CAR")) {
            if (args.size() < 3 ) {
                throw new IllegalArgumentException("A car requires at least 3 arguments.");
            }
            else if (args.size () == 3){
                if(POInstance.findCustomer(args.get(2))) {
                    if(args.get(0).equalsIgnoreCase("COMPACT")) {
                        Car registerCar = new Car(Car.CarType.COMPACT,args.get(1),POInstance.returnFoundCustomer());
                        POInstance.registerCar(registerCar);
                    }
                    else {
                        Car registerCar = new Car(Car.CarType.SUV,args.get(1),POInstance.returnFoundCustomer());
                        POInstance.registerCar(registerCar);
                    }
                }
                else {
                    System.out.println ("Customer not Found");
                }
            }
            else if (args.size () == 11) {
                Customer customerToRegister = registerCustomerCMD(args.get(2), args.get(3),
                        args.get(4), args.get(5),args.get(6),args.get(7),args.get(8),args.get(9),args.get(10));
                if(args.get(0).equalsIgnoreCase("COMPACT")) {
                    Car registerCar = new Car(Car.CarType.COMPACT,args.get(1),customerToRegister);
                    POInstance.registerCar(registerCar);
                }
                else {
                    Car registerCar = new Car(Car.CarType.SUV,args.get(1),customerToRegister);
                    POInstance.registerCar(registerCar);
                }
            }
            else {
                throw new IllegalArgumentException("A car requires either 3 (for pre-existing customers) "
                        + "or 11 arguments(for new customers).");
            }
        }
        //Command to register a parking charge
        else if (command.equalsIgnoreCase("PARK")) {
            if (args.size() != 4) {
                throw new IllegalArgumentException("A parking requires 4 arguments.");
            }
            else {
                if(POInstance.findPermit(args.get(0))) {
                    if(POInstance.findParkingLot(args.get(1))) {
                        LocalDateTime start = LocalDateTime.parse(args.get(2), formatter);
                        LocalDateTime end = LocalDateTime.parse(args.get(2), formatter);
                        POInstance.park(POInstance.returnFoundPermit(),POInstance.returnFoundParkingLot(),start,end);
                    }
                    else {
                        System.out.println ("Parking Lot not Found");
                    }
                }
                else {
                    System.out.println ("Car Permit not Found");
                }
            }
        }
        //Command to retrieve list of charges for input Customer or Car
        else if (command.equalsIgnoreCase("CHARGES")) {
            if (args.size() != 1) {
                throw new IllegalArgumentException("A parking requires 1 arguments.");
            }
            else {
                if(args.get(0).equalsIgnoreCase("NAME")) {
                    if(POInstance.findCustomer(args.get(1))) {
                        POInstance.tManager.getParkingCharges(POInstance.returnFoundCustomer());
                    }
                    else {
                        System.out.println ("Customer not Found");
                    }
                }
                else if (args.get(0).equalsIgnoreCase("LICENSEPLATE")) {
                    if(POInstance.findPermit(args.get(1))) {
                        POInstance.tManager.getParkingCharges(POInstance.returnFoundPermit());
                    }
                }
            }
        }
        else {
            throw new IllegalArgumentException("Command Not Found");
        }
        return "Good to go";
    }

    //* This constructor sets parameters to firstName,lastName,
    // phoneNumber,streetAddress1,streetAddress,state,zipcode.

    public Customer registerCustomerCMD(String id, String firstName, String lastName, String phoneNumber,
                                        String streetAddress1, String streetAddress2, String city, String state,
                                        String zipcode) {
        Address customerAddress = new Address (streetAddress1, streetAddress2, city, state,
                zipcode);
        Customer CustomerToRegister = new Customer(id, firstName, lastName, phoneNumber,
                customerAddress);
        POInstance.registerCustomer(CustomerToRegister);
        return CustomerToRegister; }
}
