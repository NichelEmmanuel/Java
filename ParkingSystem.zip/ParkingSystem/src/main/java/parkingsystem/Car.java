package parkingsystem;

// This class contains CarType , licensePlate, owner details of car.
// CreatedOn 07/07/2020;
// created by Nichel Emmanuel

public class Car {
    private String licensePlate;
    Customer owner;

    //* This constructor will set  attributes Car Type,licensePlate, CarCustomer
    public Car (CarType Type, String licensePlate,Customer CarCustomer ){
        this.Type = Type;
        this.licensePlate = licensePlate;
        this.owner = CarCustomer;
    }

    public Car(String s, Customer customer) {
    }

    //*  This method  gets and returns value for license plate
    public String getLicensePlate() {
        return licensePlate;
    }

    public void setLicensePlate(String licensePlate) {
        this.licensePlate = licensePlate;
    }

    //*  This method  gets and returns value for  Owner
    public Customer getOwner() {
        return owner;
    }

    public void setOwner(Customer owner) {
        this.owner = owner;
    }

    //*  This method  gets and returns value for Car type
    public CarType getCarType() {
        return Type;
    }

    public void setType(CarType Type) {
        this.Type = Type;
    }

    //*  This method  gets and returns value for  Car type enum
    public enum CarType {
        COMPACT,
        SUV;}
    CarType Type;
}
