package parkingsystem;

//* This class contains billing Parking permit details such as ID, car, and expiration date.
//* Created On 07/7/2020;
// created by Nichel Emmanuel

import java.time.LocalDateTime;

public class ParkingPermit {
    private String id;
    private Car car;
    private int citations;

    LocalDateTime current = LocalDateTime.now();

    public static final long DAY = 1000 *3600 *24;
    LocalDateTime expiration = current.plusYears(5);

    //* This constructor sets parameters to id, car
    public ParkingPermit (String id, Car car){
        this.id = id;
        this.car = car;
    }

    //* This method  gets and returns value for citations
    public int getCitations() {
        return citations;
    }

    public void setCitations(int citations) {
        this.citations = citations;
    }

    //* This method  gets and returns value for id.
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
    //* This method  gets and returns value for Car.
    public Car getCar() {
        return car;
    }
    public void setCar(Car Car) {
        this.car = Car;
    }
    //* This method  gets and returns value for current time.
    public LocalDateTime getCurrent() {
        return current;
    }

    public void setCurrent(LocalDateTime current) {
        this.current = current;
    }
    //* This method  gets and returns value for expiration date.
    public LocalDateTime getExpiration() {
        return expiration;
    }

    public void setExpiration(LocalDateTime expiration) {
        this.expiration = expiration;
    }

}
