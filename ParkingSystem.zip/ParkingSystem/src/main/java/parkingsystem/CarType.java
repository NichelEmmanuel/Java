package parkingsystem;

// This class contains CarType details of car like SUV,COMPACT.
// CreatedOn 07/07/2020;
// created by Nichel Emmanuel
public enum CarType {
    SUV, COMPACT;
}
