package parkingsystem;
// This class call the specific class based on the charge type.
// CreatedOn 07/07/2020;
// created by Nichel Emmanuel

public class ParkingChargeCalculatorFactory {

    public enum chargeType {
        OVERNIGHT,
        DAILY;
    }

    public ParkingCalculator getCalculator(chargeType calculationType){
        if (null == calculationType) {
            return new DailyCalculator();
        }
        else switch (calculationType) {
            case OVERNIGHT:
               // return new OvernightCalculator();
            default:
                return new DailyCalculator();
        }
    }
}
