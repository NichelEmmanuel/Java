package parkingsystem;

//* This class contains customer_id, first_Name, last_Name, phone_Number, and address  details of customers.
// CreatedOn 07/07/2020;
// created by Nichel Emmanuel

public class Customer {
    private String id;
    private String firstName;
    private String lastName;
    private String phoneNumber;
    Address customerAddress ;

    //* This constructor will set  attributes for customer_id,firstName,lastName,phoneNumber,address.
    public Customer (String id,String firstName, String lastName,
                     String phoneNumber, Address customerAddress){
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phoneNumber = phoneNumber;
        this.customerAddress = customerAddress;
    }

    public Customer(String s) {
    }

    //*  This method  gets and returns value for customer_id.
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    //*  This method  gets and returns value for cufirstName.
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    //*  This method  gets and returns value for lastName.
    public String getLastName() {
        return lastName;
    }


    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    //*  This method  gets and returns value for phoneNumber.
    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    //*  This method  gets and returns value for Address.
    public Address getCustomerAddress() {
        return customerAddress;
    }

    public void setCustomerAddress(Address customerAddress) {
        this.customerAddress = customerAddress;
    }

}
