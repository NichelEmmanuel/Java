package parkingsystem;

//* This is observer class for parking lot to check details start time ,end time, parking activity.
//* CreatedOn 07/07/2020;
// created by Nichel Emmanuel

import java.time.LocalDateTime;
import java.util.ArrayList;

public class ParkingLotObserver extends ParkingObserver {
    private ArrayList<CarParked> listOfActiveParking = null;
    private TransactionManager transactManager = null;

    public ParkingLotObserver(TransactionManager aManager) {
        transactManager = aManager;
        listOfActiveParking = new ArrayList<CarParked>();
    }

    public ArrayList<CarParked> getListOfActiveParking() {
        return listOfActiveParking;
    }

    public void setListOfActiveParking(ArrayList<CarParked> listOfActiveParking) {
        this.listOfActiveParking = listOfActiveParking;
    }

    public TransactionManager getTransactManager() {
        return transactManager;
    }

    public void setTransactManager(TransactionManager transactManager) {
        this.transactManager = transactManager;
    }


    private class CarParked {
        LocalDateTime timeIn;
        ParkingPermit permitRegistered;
    }



    @Override
    public void vehicleEntry(ParkingPermit customerPermit) {
        CarParked cpInstance = new CarParked();
        cpInstance.timeIn = LocalDateTime.now();
        cpInstance.permitRegistered = customerPermit;
        listOfActiveParking.add(cpInstance);
    }

    @Override
    public void vehicleExit(ParkingPermit customerPermit, ParkingLot lot) {
        int output = findPermit(customerPermit);
        if(output != -1) {
            CarParked transaction = listOfActiveParking.get(output);
            listOfActiveParking.remove(output);
            transactManager.park(transaction.timeIn, LocalDateTime.now(), customerPermit, lot);
        }
    }

    public int findPermit(ParkingPermit customerPermit) {
        for (int i = 0; i < listOfActiveParking.size(); i++) {
            if(listOfActiveParking.get(i).permitRegistered.getId().equalsIgnoreCase(customerPermit.getId())) {
                return i;
            }
        }
        return -1;
    }
}
