package parkingsystem;

//* This class contains parking office details .
// CreatedOn 07/07/2020;
// created by Nichel Emmanuel

import java.util.ArrayList;
//* This constructor sets parameters to
// parking office details like Office name , customer, lot id , office address
public class ParkingOffice {

    String parkingOfficeName;
    public ArrayList<Customer> listOfCustomers = null;
    public ArrayList<ParkingLot> listOfParkingLots = null;
    Address parkingOfficeAddress = null;
    Customer foundCustomer = null;
    PermitManager pManager = null;
    ParkingPermit foundPermit = null;
    ParkingLot foundParkingLot = null;
    TransactionManager tManager = null;
    ParkingCalculator parkingCalculatorInstance = null;
    ParkingLotObserver parkingObserver = null;

    //* This method  gets and returns value for ParkingOfficeName,ParkingOfficeAddress

    public ParkingOffice (String aParkingOfficeName, Address aParkingOfficeAddress) {
        parkingOfficeName = aParkingOfficeName;
        parkingOfficeAddress = aParkingOfficeAddress;
        listOfCustomers = new ArrayList<Customer>();
        listOfParkingLots = new ArrayList<ParkingLot>();
        tManager = new TransactionManager();
        pManager = new PermitManager();
        parkingObserver = new ParkingLotObserver(tManager);
    }

    //* This method  gets and returns value for ParkingOfficeName
    public String getParkingOfficeName() {
        return this.parkingOfficeName;
    }

    public String registerCustomer(Customer NewCustomer) {
         this.listOfCustomers.add(NewCustomer);
         return NewCustomer.getId();

    }

    //* This method  gets and returns value for newCar
    public String registerCar (Car newCar) {
        //making new instance of ParkingPermit by calling it constructor method
        pManager.registerCar(newCar);
        return newCar.getLicensePlate();
    }

    //* This method  gets and returns value for newParkingLot
    public void registerParkingLot(ParkingLot newParkingLot) {
        newParkingLot.register(parkingObserver);
        listOfParkingLots.add(newParkingLot);}

    //* This method  gets and returns value for customername
    public Boolean findCustomer(String customername) {
        for (int i = 0; i < listOfCustomers.size(); i++) {
            if((listOfCustomers.get(i).getFirstName() + " "
                    + listOfCustomers.get(i).getLastName()).equalsIgnoreCase(customername))
            {
                foundCustomer = listOfCustomers.get(i);
                return true;
            }
        }
        return false;
    }

    //* This method  gets and returns value for customer
    public Customer returnFoundCustomer() {
        return this.foundCustomer;
    }

    //* This method  gets and returns value for licenseplate
    public Boolean findPermit(String licenseplate) {
        for (int i = 0; i < pManager.listOfParkingPermit.size(); i++) {
            if(pManager.listOfParkingPermit.get(i).getCar().getLicensePlate().equalsIgnoreCase(licenseplate))
            {
                foundPermit = pManager.listOfParkingPermit.get(i);
                return true;
            }
        }
        return false;
    }

    public ParkingPermit returnFoundPermit() {
        return this.foundPermit;
    }

    //* This method  gets and returns value for ParkingLotName
    public Boolean findParkingLot(String ParkingLotName){
        for (int i = 0; i < pManager.listOfParkingPermit.size(); i++) {
            if(listOfParkingLots.get(i).getParkingLotName().equalsIgnoreCase(ParkingLotName)) {
                foundParkingLot = listOfParkingLots.get(i);
                return true;
            }
        }
        return false;
    }

    //* This method  gets and returns value for Permit, parkingLot, start, end
    public void park(ParkingPermit Permit, ParkingLot parkingLot,
                     java.time.LocalDateTime start, java.time.LocalDateTime end) {
        tManager.park(start,end, Permit, parkingLot);
    }

    public ParkingLot returnFoundParkingLot() {
        return this.foundParkingLot;
    }
}

