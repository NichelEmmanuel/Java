package parkingsystem;
// This class manages the transaction of the car and customer.
// CreatedOn 07/07/2020;
// created by Nichel Emmanuel

import java.util.ArrayList;
import java.time.LocalDateTime;
import java.time.Duration;

public class TransactionManager {
    private ArrayList<ParkingTransaction> listOfParkingTransaction = null;
    private ParkingChargeCalculatorFactory pcFactory = new ParkingChargeCalculatorFactory();

    //constructor

    public TransactionManager () {
        listOfParkingTransaction = new ArrayList<ParkingTransaction>();
    }
    //method to get and set parameters for dateTransactionStart,dateTransactionEnd,
    // permitTransaction,parkingTransaction

    public ParkingTransaction park(LocalDateTime dateTransactionStart, LocalDateTime dateTransactionEnd,
                                   ParkingPermit permitTransaction, ParkingLot parkingTransaction) {
        long cost = 0;

            if((dateTransactionStart.getHour() >= 21 || dateTransactionEnd.getHour() >=21 || Duration.between
                    (dateTransactionStart,dateTransactionEnd).toDays() > 0))
            {
                ParkingCalculator transactionCalculator = pcFactory.getCalculator(ParkingChargeCalculatorFactory.chargeType.OVERNIGHT);
                cost = transactionCalculator.calculate(permitTransaction, parkingTransaction, dateTransactionStart, dateTransactionEnd);
            }
            else {
                ParkingCalculator transactionCalculator = pcFactory.getCalculator(ParkingChargeCalculatorFactory.chargeType.DAILY);
                cost = transactionCalculator.calculate(permitTransaction, parkingTransaction, dateTransactionStart, dateTransactionEnd);
            }

        Money chargedAmount = new Money(cost,"USD");
        ParkingTransaction newTransaction = new ParkingTransaction(dateTransactionStart,dateTransactionEnd , permitTransaction, parkingTransaction,chargedAmount);
        listOfParkingTransaction.add(newTransaction);
        return newTransaction;
    }

    //method to get and set parametres forparkingChargesPermit
    public Money getParkingCharges (ParkingPermit parkingChargesPermit) {
        long temp = 0;

        for (int i = 0; i < listOfParkingTransaction.size();i++) {
            if (listOfParkingTransaction.get(i).getParkingPermit() == parkingChargesPermit) {
                temp += listOfParkingTransaction.get(i).getChargedAmount().getAmount();
            }
        }
        Money total = new Money(temp,"USD");
        return total;
    }

    //method to get and set parametres for parkingChargesCustomer
    public Money getParkingCharges (Customer parkingChargesCustomer) {
        long temp = 0;
        for (int i = 0; i < listOfParkingTransaction.size();i++) {
            if (listOfParkingTransaction.get(i).getParkingPermit().getCar().getOwner() == parkingChargesCustomer) {
                temp += listOfParkingTransaction.get(i).getChargedAmount().getAmount();
            }
        }
        Money total = new Money(temp,"USD");
        return total;
    }
}