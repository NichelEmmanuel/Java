package parkingsystem;
// This class manages the permit to a car and customer.
// CreatedOn 07/07/2020;
// created by Nichel Emmanuel

import java.util.ArrayList;
public class PermitManager {

    public ArrayList<ParkingPermit> listOfParkingPermit = null;

    // method retuens and set param for listOfParkingPermit
    public ArrayList<ParkingPermit> getListOfParkingPermit() {
        return listOfParkingPermit;
    }

    public void setListOfParkingPermit(ArrayList<ParkingPermit> listOfParkingPermit) {
        this.listOfParkingPermit = listOfParkingPermit;
    }

    // method returns and set param for new car
    public PermitManager (){
        this.listOfParkingPermit = new ArrayList<ParkingPermit>();
    }

    public void registerCar(Car NewCar){
        String id = Integer.toString(listOfParkingPermit.size());
        ParkingPermit entryPermit = new ParkingPermit(id,NewCar);
        this.listOfParkingPermit.add(entryPermit);}


}
