package parkingsystem;
// This class registers the parking.
// CreatedOn 07/07/2020;
// created by Nichel Emmanuel

public interface ParkingActor {
    public void register(ParkingObserver parkingObserverToRegister);

}
