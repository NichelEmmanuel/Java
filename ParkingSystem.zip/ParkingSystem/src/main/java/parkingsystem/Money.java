package parkingsystem;

//* This class contains billing amount details like amount and currency for customers
// CreatedOn 07/07/2020;
// created by Nichel Emmanuel

//* This is the constructor for Money class
public class Money {
    private long amount;
    private String currency;

    // * This constructor will set  attributes for amount and  currency
    public Money (long amount, String currency) {
        this.amount = amount;
        this.currency = currency;
    }

    //* This method  gets and returns value for amount
    public long getAmount() {
        return amount;
    }

    public void setAmount(long amount) {
        this.amount = amount;
    }

    //* This method  gets and returns value for currency
    public String getCurrency() {
        return currency;
    }
    public void setCurrency(String currency) {
        this.currency = currency;
    }
}
