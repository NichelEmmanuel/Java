package parkingsystem;
//* This class manages the parking transactions
//* Created On 07/7/2020; created by Nichel Emmanuel

import java.time.LocalDateTime;

public class ParkingTransaction {
    private LocalDateTime start;
    private LocalDateTime end;
    private ParkingPermit permit;
    private ParkingLot parkingLot;
    Money chargedAmount;

    //constructor sets parameters for start, end, permit,parkingLot,chargedAmount
    public ParkingTransaction (LocalDateTime start,LocalDateTime end, ParkingPermit permit, ParkingLot parkingLot, Money chargedAmount){
        this.start = start;
        this.end = end;
        this.parkingLot = parkingLot;
        this.permit = permit;
        this.chargedAmount = chargedAmount;
    }

    //* method  gets and returns value for start time
    public LocalDateTime getStart() {
        return start;
    }

    public void setStart(LocalDateTime start) {
        this.start = start;
    }

    //* method  gets and returns value for end time
    public LocalDateTime getEnd() {
        return end;
    }

    public void setEnd(LocalDateTime end) {
        this.end = end;
    }

    //* method  gets and returns value for permit time
    public ParkingPermit getPermit() {
        return permit;
    }

    public void setPermit(ParkingPermit permit) {
        this.permit = permit;
    }

    //* method  gets and returns value for  parkingLot
    public ParkingLot getParkingLot() {
        return parkingLot;
    }

    public void setParkingLot(ParkingLot parkingLot) {
        this.parkingLot = parkingLot;
    }

    //* method  gets and returns value for parkingLot
    public ParkingPermit getParkingPermit(){
        return this.permit;
    }

    //* method  gets and returns value for charged ammount
    public Money getChargedAmount() {
        return chargedAmount;
    }

    public void setChargedAmount(Money chargedAmount) {
        this.chargedAmount = chargedAmount;
    }

}
