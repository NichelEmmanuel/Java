package parkingsystem;
// This class contains Street1, Street2,  City, State, and postal code details of customers.
// CreatedOn 07/07/2020;
// created by Nichel Emmanuel

public class Address {
    private String streetAddress1;
    private String streetAddress2 ;
    private String city;
    private String state;
    private String zipcode;

    // * This constructor will set  attributes street1, street2,  city,  state,  zip
    public Address (String streetAddress1,String streetAddress2,
                    String city,String state,String zipcode){
        this.streetAddress1 = streetAddress1;
        this.streetAddress2 = streetAddress2;
        this.city = city;
        this.state = state;
        this.zipcode = zipcode;
    }

    public Address() {

    }

    // *  This method  gets and returns value for  streetAddress
    public String getStreetAddress1() {
        return streetAddress1;
    }

    public void setStreetAddress1(String streetAddress1) {
        this.streetAddress1 = streetAddress1;
    }

    // * T This method  gets and returns value for streetAddress2
    public String getStreetAddress2() {
        return streetAddress2;
    }

    public void setStreetAddress2(String streetAddress2) {
        this.streetAddress2 = streetAddress2;
    }

    // *  This method  gets and returns value for City
    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    // *  This method  gets and returns value for State
    public String getState() {
        return state;
    }


    public void setState(String state) {
        this.state = state;
    }

    // *  This method  gets and returns value forZip code
    public String getZipcode() {
        return zipcode;
    }

    public void setZipcode(String zipcode) {
        this.zipcode = zipcode;
    }
}
